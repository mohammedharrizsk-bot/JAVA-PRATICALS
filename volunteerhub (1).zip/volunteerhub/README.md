# VolunteerHub – NGO Volunteer Sign-up and Event Tracker

A simple Spring Boot REST API for a campus NGO / community group. Organizers create events, volunteers
sign up, organizers mark attendance and record hours, and anyone can see upcoming events and total hours.

## 1. Features
- Create / list / update / delete events (filter by **category** and **date**)
- Register volunteers (unique email, validated phone)
- Sign up for events with **capacity**, **duplicate** and **404** rules
- Cancel a sign-up
- Mark attendance (ATTENDED / NOT_ATTENDED)
- Record hours (only if attended, never negative)
- Total hours per volunteer, upcoming events with open slots, dashboard totals
- browser web page, global JSON error handling, sample data, unit + integration tests

## 2. Technology stack
Java 17 · Spring Boot 3.2 · Spring Web · Spring Data JPA · Jakarta Validation · MySQL (H2 for quick demo/tests)
· Lombok · Maven · plain HTML/JavaScript web page

## 3. Architecture
```
Controller  ->  Service  ->  Repository  ->  Database
 (HTTP)        (rules)       (queries)
```
```
src/main/java/com/volunteerhub
├── controller   EventController, VolunteerController, SignUpController, AttendanceController, DashboardController
├── service      EventService, VolunteerService, SignUpService, AttendanceService, DashboardService
├── repository   EventRepository, VolunteerRepository, SignUpRepository, AttendanceRecordRepository
├── entity       Event, Volunteer, SignUp, SignUpStatus, AttendanceRecord
├── dto          request/response records (entities are never returned directly)
├── exception    BusinessException + specific exceptions + GlobalExceptionHandler
└── config       DataSeeder
```

## 4. Database schema
| Table | Columns |
|---|---|
| events | id, name, description, date, location, capacity, category, created_at |
| volunteers | id, name, email (unique), phone, registration_date, active |
| signups | id, volunteer_id (FK), event_id (FK), signup_time, status (REGISTERED/CANCELLED) |
| attendance_records | id, signup_id (FK, unique), attended, hours_contributed, attendance_time |

Relationships:
```
Event 1 ---- * SignUp * ---- 1 Volunteer
SignUp 1 ---- 0..1 AttendanceRecord
```
`AttendanceRecord` reaches the volunteer and event **through its sign-up**, so ids are not duplicated.
Relationships are one-directional (SignUp -> Volunteer/Event), which avoids infinite JSON loops.
Tables are created automatically by Hibernate (`ddl-auto=update`).

## 5. Requirements
- JDK 17 or later
- Maven 3.8+
- MySQL 8 (only for the default setup – not needed for the H2 demo)

## 6. Database setup (MySQL)
```sql
CREATE DATABASE volunteerhub;
```
(The default URL also has `createDatabaseIfNotExist=true`, so it is created for you if missing.)

## 7. Configuration
`src/main/resources/application.properties` reads environment variables:

| Variable | Default |
|---|---|
| DB_URL | jdbc:mysql://localhost:3306/volunteerhub?... |
| DB_USERNAME | root |
| DB_PASSWORD | BORN2007 (change for your own machine) |

Linux/macOS: `export DB_PASSWORD=mysecret`  ·  Windows (cmd): `set DB_PASSWORD=mysecret`

## 8. Run
```bash
mvn clean install
mvn spring-boot:run
```
**No MySQL? Use the built-in in-memory H2 database:**
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=h2
```
Sample data is inserted automatically when the database is empty
(5 volunteers, 3 events, sign-ups, attendance and hours):

| Event | State |
|---|---|
| Beach Cleanup Drive (id 1) | OPEN SLOTS (3 of 50 taken) |
| Blood Donation Camp (id 2) | **FULL** (3 of 3 taken) |
| Tree Plantation Drive (id 3) | Past event with attendance + hours |

## 9. Web page
Open **http://localhost:8080** in your browser. The page has Dashboard, Events, Volunteers, Sign Up and Attendance & Hours tabs.

## 10. API endpoints
| Method | URL | Description | Success |
|---|---|---|---|
| POST | /api/events | Create event | 201 |
| GET | /api/events?category=&date= | List/filter events | 200 |
| GET | /api/events/upcoming | Upcoming events with open slots | 200 |
| GET | /api/events/{id} | One event | 200 |
| PUT | /api/events/{id} | Update event | 200 |
| DELETE | /api/events/{id} | Delete event (no sign-ups) | 204 |
| POST | /api/volunteers | Create volunteer | 201 |
| GET | /api/volunteers | List volunteers | 200 |
| GET | /api/volunteers/{id} | One volunteer | 200 |
| GET | /api/volunteers/{id}/hours | Total hours | 200 |
| POST | /api/events/{eventId}/signup | Sign up | 201 |
| GET | /api/events/{eventId}/signups | Sign-ups of event | 200 |
| GET | /api/volunteers/{volunteerId}/signups | Sign-ups of volunteer | 200 |
| DELETE | /api/signups/{signupId} | Cancel sign-up | 204 |
| POST | /api/attendance | Mark attendance | 201 |
| PUT | /api/attendance/{id} | Change attendance | 200 |
| PUT | /api/attendance/{id}/hours | Record hours | 200 |
| GET | /api/events/{eventId}/attendance | Attendance of event | 200 |
| GET | /api/dashboard | Totals | 200 |

## 11. Example requests and responses
**Create event** `POST /api/events`
```json
{ "name": "Beach Cleanup Drive", "description": "Community beach cleaning activity",
  "date": "2026-10-15", "location": "Marina Beach", "capacity": 50, "category": "Environment" }
```
**Create volunteer** `POST /api/volunteers`
```json
{ "name": "John Doe", "email": "john@example.com", "phone": "9876543210" }
```
**Sign up** `POST /api/events/1/signup`
```json
{ "volunteerId": 5 }
```
**Mark attendance** `POST /api/attendance`
```json
{ "signupId": 1, "attended": true }
```
**Record hours** `PUT /api/attendance/1/hours`
```json
{ "hoursContributed": 4.5 }
```
**Total hours** `GET /api/volunteers/1/hours`
```json
{ "volunteerId": 1, "volunteerName": "John Doe", "totalHours": 4.5 }
```
**Upcoming** `GET /api/events/upcoming`
```json
[ { "eventId": 1, "name": "Beach Cleanup Drive", "date": "2026-10-15", "location": "Marina Beach",
    "capacity": 50, "registeredVolunteers": 3, "openSlots": 47, "category": "Environment" } ]
```
**Error (event full)** `409`
```json
{ "timestamp": "2026-09-28T10:00:00", "status": 409, "error": "EVENT_FULL",
  "message": "This event has reached its volunteer capacity.", "path": "/api/events/2/signup" }
```

## 12. Business rules (all in the service layer)
1. **Capacity** – `SignUpService.signUp` counts REGISTERED sign-ups *before* saving; if count >= capacity -> `409 EVENT_FULL`.
   The event row is loaded with a database lock (`findByIdForUpdate`), so two people taking the last slot at the
   same moment are processed one after the other and capacity can never be exceeded.
2. **Duplicate sign-up** – same volunteer + same event while REGISTERED -> `409 DUPLICATE_SIGNUP`.
3. **Missing volunteer/event** -> `404 RESOURCE_NOT_FOUND`.
4. **Attendance** – only REGISTERED sign-ups can get an attendance record (one per sign-up).
5. **Hours** – `AttendanceService.recordHours` checks `attended == true` first (else `400 VOLUNTEER_NOT_ATTENDED`),
   then hours >= 0 (else `400`). Nothing is saved when a rule fails.
   If someone is later changed to NOT_ATTENDED, their hours reset to 0.
6. **Total hours** – sums hours only from records with `attended = true`.
7. **Upcoming events** – `date >= today` and `registered < capacity`, sorted by date.
8. **Cancelling** a sign-up sets status CANCELLED, which frees the slot.

## 13. Testing
```bash
mvn test
```
Tests use an in-memory H2 database (profile `test`), no MySQL needed.
- `SignUpServiceTest` – Mockito unit tests: success, full, duplicate, missing volunteer, missing event
- `AttendanceServiceTest` – Mockito unit tests: attended, not attended, hours saved, hours rejected, negative hours
- `VolunteerHubApiTest` – full API tests: event/volunteer validation, sign-up rules, hours rules, total hours,
  upcoming events (open / full / past), filtering, dashboard

## 14. Postman examples
Create these requests manually in Postman:
1. `GET  http://localhost:8080/api/events/upcoming`
2. `POST http://localhost:8080/api/events/2/signup` body `{"volunteerId":5}` -> **409 EVENT_FULL** (event 2 is full)
3. `POST http://localhost:8080/api/events/1/signup` body `{"volunteerId":5}` -> 201
4. Repeat step 3 -> **409 DUPLICATE_SIGNUP**
5. `POST http://localhost:8080/api/attendance` body `{"signupId":1,"attended":false}` -> then
   `PUT http://localhost:8080/api/attendance/{id}/hours` body `{"hoursContributed":2}` -> **400 VOLUNTEER_NOT_ATTENDED**
6. `GET  http://localhost:8080/api/volunteers/1/hours` -> `{"totalHours": ...}`

## 15. Assumptions
- No login/security (the brief did not ask for it); "organizer" actions are open endpoints.
- Event date only has to be a valid `yyyy-MM-dd` date (past dates allowed so old events can be recorded).
- Phone number = exactly 10 digits. Email is stored in lowercase and must be unique.
- Events that already have sign-ups cannot be deleted (cancel/keep them instead).
