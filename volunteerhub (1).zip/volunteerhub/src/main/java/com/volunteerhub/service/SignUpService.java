package com.volunteerhub.service;

import com.volunteerhub.dto.SignUpResponse;
import com.volunteerhub.entity.Event;
import com.volunteerhub.entity.SignUp;
import com.volunteerhub.entity.SignUpStatus;
import com.volunteerhub.entity.Volunteer;
import com.volunteerhub.exception.BusinessException;
import com.volunteerhub.exception.DuplicateSignupException;
import com.volunteerhub.exception.EventFullException;
import com.volunteerhub.exception.ResourceNotFoundException;
import com.volunteerhub.repository.EventRepository;
import com.volunteerhub.repository.SignUpRepository;
import com.volunteerhub.repository.VolunteerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SignUpService {

    private final SignUpRepository signUpRepository;
    private final EventRepository eventRepository;
    private final VolunteerRepository volunteerRepository;

    /**
     * Sign-up steps (the capacity check happens BEFORE anything is saved):
     * 1. find volunteer  2. find event (row is locked)  3. duplicate check
     * 4. count current registrations  5. reject if full  6. save
     */
    @Transactional
    public SignUpResponse signUp(Long eventId, Long volunteerId) {
        Volunteer volunteer = volunteerRepository.findById(volunteerId)
                .orElseThrow(() -> new ResourceNotFoundException("Volunteer", volunteerId));

        // The lock makes concurrent sign-ups for the same event wait for each other,
        // so two people can never both take the last slot.
        Event event = eventRepository.findByIdForUpdate(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event", eventId));

        if (!volunteer.isActive()) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "VOLUNTEER_INACTIVE",
                    "Inactive volunteers cannot sign up for events.");
        }

        if (signUpRepository.existsByVolunteerIdAndEventIdAndStatus(volunteerId, eventId, SignUpStatus.REGISTERED)) {
            throw new DuplicateSignupException();
        }

        long registered = signUpRepository.countByEventIdAndStatus(eventId, SignUpStatus.REGISTERED);
        if (registered >= event.getCapacity()) {
            throw new EventFullException();
        }

        SignUp signUp = new SignUp();
        signUp.setVolunteer(volunteer);
        signUp.setEvent(event);
        signUp.setStatus(SignUpStatus.REGISTERED);
        return SignUpResponse.from(signUpRepository.save(signUp));
    }

    @Transactional(readOnly = true)
    public List<SignUpResponse> getSignUpsForEvent(Long eventId) {
        if (!eventRepository.existsById(eventId)) {
            throw new ResourceNotFoundException("Event", eventId);
        }
        return signUpRepository.findByEventId(eventId).stream().map(SignUpResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public List<SignUpResponse> getSignUpsForVolunteer(Long volunteerId) {
        if (!volunteerRepository.existsById(volunteerId)) {
            throw new ResourceNotFoundException("Volunteer", volunteerId);
        }
        return signUpRepository.findByVolunteerId(volunteerId).stream().map(SignUpResponse::from).toList();
    }

    /** Cancelling does not delete the row, it only changes the status to CANCELLED. */
    @Transactional
    public void cancelSignUp(Long signupId) {
        SignUp signUp = signUpRepository.findById(signupId)
                .orElseThrow(() -> new ResourceNotFoundException("SignUp", signupId));

        if (signUp.getStatus() == SignUpStatus.CANCELLED) {
            throw new BusinessException(HttpStatus.CONFLICT, "ALREADY_CANCELLED",
                    "This sign-up is already cancelled.");
        }
        signUp.setStatus(SignUpStatus.CANCELLED);
        signUpRepository.save(signUp);
    }
}
