package com.volunteerhub.service;

import com.volunteerhub.dto.DashboardResponse;
import com.volunteerhub.entity.SignUpStatus;
import com.volunteerhub.repository.AttendanceRecordRepository;
import com.volunteerhub.repository.EventRepository;
import com.volunteerhub.repository.SignUpRepository;
import com.volunteerhub.repository.VolunteerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final EventRepository eventRepository;
    private final VolunteerRepository volunteerRepository;
    private final SignUpRepository signUpRepository;
    private final AttendanceRecordRepository attendanceRepository;

    @Transactional(readOnly = true)
    public DashboardResponse getDashboard() {
        Double hours = attendanceRepository.totalHoursOfAll();
        return new DashboardResponse(
                eventRepository.count(),
                eventRepository.countByDateGreaterThanEqual(LocalDate.now()),
                volunteerRepository.count(),
                signUpRepository.countByStatus(SignUpStatus.REGISTERED),
                hours == null ? 0.0 : hours);
    }
}
