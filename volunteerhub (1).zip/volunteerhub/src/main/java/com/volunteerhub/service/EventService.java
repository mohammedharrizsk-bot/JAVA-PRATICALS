package com.volunteerhub.service;

import com.volunteerhub.dto.EventRequest;
import com.volunteerhub.dto.EventResponse;
import com.volunteerhub.dto.UpcomingEventResponse;
import com.volunteerhub.entity.Event;
import com.volunteerhub.entity.SignUpStatus;
import com.volunteerhub.exception.BusinessException;
import com.volunteerhub.exception.ResourceNotFoundException;
import com.volunteerhub.repository.EventRepository;
import com.volunteerhub.repository.SignUpRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EventService {

    private final EventRepository eventRepository;
    private final SignUpRepository signUpRepository;

    @Transactional
    public EventResponse createEvent(EventRequest request) {
        Event event = new Event();
        copyFields(request, event);
        return EventResponse.from(eventRepository.save(event));
    }

    /** Both filters are optional. Category is not case sensitive. */
    @Transactional(readOnly = true)
    public List<EventResponse> getEvents(String category, LocalDate date) {
        return eventRepository.findAll().stream()
                .filter(e -> category == null || category.isBlank()
                        || (e.getCategory() != null && e.getCategory().equalsIgnoreCase(category)))
                .filter(e -> date == null || e.getDate().equals(date))
                .map(EventResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public EventResponse getEvent(Long id) {
        return EventResponse.from(findEvent(id));
    }

    @Transactional
    public EventResponse updateEvent(Long id, EventRequest request) {
        Event event = findEvent(id);

        long registered = signUpRepository.countByEventIdAndStatus(id, SignUpStatus.REGISTERED);
        if (request.capacity() < registered) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "INVALID_CAPACITY",
                    "Capacity cannot be lower than the current number of registered volunteers (" + registered + ").");
        }

        copyFields(request, event);
        return EventResponse.from(eventRepository.save(event));
    }

    @Transactional
    public void deleteEvent(Long id) {
        Event event = findEvent(id);
        if (signUpRepository.existsByEventId(id)) {
            throw new BusinessException(HttpStatus.CONFLICT, "EVENT_HAS_SIGNUPS",
                    "This event already has sign-ups and cannot be deleted.");
        }
        eventRepository.delete(event);
    }

    /** Events today or later that still have free slots, sorted by date. */
    @Transactional(readOnly = true)
    public List<UpcomingEventResponse> getUpcomingEventsWithOpenSlots() {
        return eventRepository.findByDateGreaterThanEqualOrderByDateAsc(LocalDate.now()).stream()
                .map(e -> UpcomingEventResponse.from(e,
                        signUpRepository.countByEventIdAndStatus(e.getId(), SignUpStatus.REGISTERED)))
                .filter(u -> u.openSlots() > 0)
                .toList();
    }

    private Event findEvent(Long id) {
        return eventRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Event", id));
    }

    private void copyFields(EventRequest request, Event event) {
        event.setName(request.name().trim());
        event.setDescription(request.description());
        event.setDate(request.date());
        event.setLocation(request.location().trim());
        event.setCapacity(request.capacity());
        event.setCategory(request.category());
    }
}
