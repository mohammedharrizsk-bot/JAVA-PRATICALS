package com.volunteerhub.service;

import com.volunteerhub.dto.VolunteerHoursResponse;
import com.volunteerhub.dto.VolunteerRequest;
import com.volunteerhub.dto.VolunteerResponse;
import com.volunteerhub.entity.Volunteer;
import com.volunteerhub.exception.BusinessException;
import com.volunteerhub.exception.ResourceNotFoundException;
import com.volunteerhub.repository.AttendanceRecordRepository;
import com.volunteerhub.repository.VolunteerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VolunteerService {

    private final VolunteerRepository volunteerRepository;
    private final AttendanceRecordRepository attendanceRecordRepository;

    @Transactional
    public VolunteerResponse createVolunteer(VolunteerRequest request) {
        String email = request.email().trim().toLowerCase();

        if (volunteerRepository.existsByEmail(email)) {
            throw new BusinessException(HttpStatus.CONFLICT, "DUPLICATE_EMAIL",
                    "A volunteer with this email already exists.");
        }

        Volunteer volunteer = new Volunteer();
        volunteer.setName(request.name().trim());
        volunteer.setEmail(email);
        volunteer.setPhone(request.phone());
        return VolunteerResponse.from(volunteerRepository.save(volunteer));
    }

    @Transactional(readOnly = true)
    public List<VolunteerResponse> getAllVolunteers() {
        return volunteerRepository.findAll().stream().map(VolunteerResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public VolunteerResponse getVolunteer(Long id) {
        return VolunteerResponse.from(findVolunteer(id));
    }

    /** Sum of hours from attendance records where attended = true. */
    @Transactional(readOnly = true)
    public VolunteerHoursResponse getTotalHours(Long id) {
        Volunteer volunteer = findVolunteer(id);
        Double total = attendanceRecordRepository.totalHoursByVolunteer(id);
        return new VolunteerHoursResponse(volunteer.getId(), volunteer.getName(), total == null ? 0.0 : total);
    }

    private Volunteer findVolunteer(Long id) {
        return volunteerRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Volunteer", id));
    }
}
