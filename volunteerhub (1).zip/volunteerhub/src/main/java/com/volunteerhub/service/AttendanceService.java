package com.volunteerhub.service;

import com.volunteerhub.dto.AttendanceRequest;
import com.volunteerhub.dto.AttendanceResponse;
import com.volunteerhub.entity.AttendanceRecord;
import com.volunteerhub.entity.SignUp;
import com.volunteerhub.entity.SignUpStatus;
import com.volunteerhub.exception.BusinessException;
import com.volunteerhub.exception.InvalidHoursException;
import com.volunteerhub.exception.ResourceNotFoundException;
import com.volunteerhub.exception.VolunteerNotAttendedException;
import com.volunteerhub.repository.AttendanceRecordRepository;
import com.volunteerhub.repository.EventRepository;
import com.volunteerhub.repository.SignUpRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AttendanceService {

    private final AttendanceRecordRepository attendanceRepository;
    private final SignUpRepository signUpRepository;
    private final EventRepository eventRepository;

    /** Creates the attendance record for a sign-up. Only REGISTERED sign-ups are allowed. */
    @Transactional
    public AttendanceResponse markAttendance(AttendanceRequest request) {
        SignUp signUp = signUpRepository.findById(request.signupId())
                .orElseThrow(() -> new ResourceNotFoundException("SignUp", request.signupId()));

        if (signUp.getStatus() != SignUpStatus.REGISTERED) {
            throw new BusinessException(HttpStatus.BAD_REQUEST, "SIGNUP_NOT_REGISTERED",
                    "Attendance can only be recorded for registered volunteers.");
        }
        if (attendanceRepository.existsBySignupId(signUp.getId())) {
            throw new BusinessException(HttpStatus.CONFLICT, "ATTENDANCE_ALREADY_RECORDED",
                    "Attendance is already recorded for this sign-up. Use PUT /api/attendance/{id} to change it.");
        }

        AttendanceRecord record = new AttendanceRecord();
        record.setSignup(signUp);
        record.setAttended(request.attended());
        record.setHoursContributed(0.0);
        return AttendanceResponse.from(attendanceRepository.save(record));
    }

    /** Changes ATTENDED / NOT_ATTENDED. If set to not attended, the hours are reset to 0. */
    @Transactional
    public AttendanceResponse updateAttendance(Long attendanceId, boolean attended) {
        AttendanceRecord record = findRecord(attendanceId);
        record.setAttended(attended);
        if (!attended) {
            record.setHoursContributed(0.0);
        }
        return AttendanceResponse.from(attendanceRepository.save(record));
    }

    /**
     * Hours steps:
     * 1. find record  2. attended must be true  3. hours must be >= 0  4. save
     */
    @Transactional
    public AttendanceResponse recordHours(Long attendanceId, Double hours) {
        AttendanceRecord record = findRecord(attendanceId);

        if (!record.isAttended()) {
            throw new VolunteerNotAttendedException();
        }
        if (hours == null || hours < 0) {
            throw new InvalidHoursException();
        }

        record.setHoursContributed(hours);
        return AttendanceResponse.from(attendanceRepository.save(record));
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponse> getAttendanceForEvent(Long eventId) {
        if (!eventRepository.existsById(eventId)) {
            throw new ResourceNotFoundException("Event", eventId);
        }
        return attendanceRepository.findBySignupEventId(eventId).stream()
                .map(AttendanceResponse::from)
                .toList();
    }

    private AttendanceRecord findRecord(Long id) {
        return attendanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("AttendanceRecord", id));
    }
}
