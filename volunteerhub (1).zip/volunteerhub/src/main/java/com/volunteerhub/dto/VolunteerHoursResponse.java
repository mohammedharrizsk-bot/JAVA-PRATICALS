package com.volunteerhub.dto;

public record VolunteerHoursResponse(Long volunteerId, String volunteerName, double totalHours) {
}
