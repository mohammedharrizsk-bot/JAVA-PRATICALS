package com.volunteerhub.dto;

import com.volunteerhub.entity.AttendanceRecord;

import java.time.LocalDateTime;

public record AttendanceResponse(
        Long attendanceId,
        Long signupId,
        Long volunteerId,
        String volunteerName,
        Long eventId,
        String eventName,
        boolean attended,
        String attendanceStatus,
        Double hoursContributed,
        LocalDateTime attendanceTime) {

    public static AttendanceResponse from(AttendanceRecord a) {
        return new AttendanceResponse(
                a.getId(),
                a.getSignup().getId(),
                a.getSignup().getVolunteer().getId(),
                a.getSignup().getVolunteer().getName(),
                a.getSignup().getEvent().getId(),
                a.getSignup().getEvent().getName(),
                a.isAttended(),
                a.isAttended() ? "ATTENDED" : "NOT_ATTENDED",
                a.getHoursContributed(),
                a.getAttendanceTime());
    }
}
