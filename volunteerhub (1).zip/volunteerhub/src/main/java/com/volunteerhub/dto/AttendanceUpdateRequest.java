package com.volunteerhub.dto;

import jakarta.validation.constraints.NotNull;

public record AttendanceUpdateRequest(
        @NotNull(message = "attended is required (true or false)")
        Boolean attended) {
}
