package com.volunteerhub.dto;

import com.volunteerhub.entity.SignUp;
import com.volunteerhub.entity.SignUpStatus;

import java.time.LocalDateTime;

public record SignUpResponse(
        Long signupId,
        Long volunteerId,
        String volunteerName,
        Long eventId,
        String eventName,
        LocalDateTime signupTime,
        SignUpStatus status) {

    public static SignUpResponse from(SignUp s) {
        return new SignUpResponse(s.getId(), s.getVolunteer().getId(), s.getVolunteer().getName(),
                s.getEvent().getId(), s.getEvent().getName(), s.getSignupTime(), s.getStatus());
    }
}
