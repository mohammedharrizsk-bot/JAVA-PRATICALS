package com.volunteerhub.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

/** Body used to create or update an event. */
public record EventRequest(
        @NotBlank(message = "Event name is required")
        @Size(max = 150, message = "Event name must be at most 150 characters")
        String name,

        @Size(max = 1000, message = "Description must be at most 1000 characters")
        String description,

        @NotNull(message = "Date is required (format yyyy-MM-dd)")
        LocalDate date,

        @NotBlank(message = "Location is required")
        String location,

        @NotNull(message = "Capacity is required")
        @Positive(message = "Capacity must be greater than 0")
        Integer capacity,

        String category) {
}
