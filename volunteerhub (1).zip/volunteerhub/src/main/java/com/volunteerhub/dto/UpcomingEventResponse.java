package com.volunteerhub.dto;

import com.volunteerhub.entity.Event;

import java.time.LocalDate;

public record UpcomingEventResponse(
        Long eventId,
        String name,
        LocalDate date,
        String location,
        Integer capacity,
        long registeredVolunteers,
        long openSlots,
        String category) {

    public static UpcomingEventResponse from(Event e, long registered) {
        return new UpcomingEventResponse(e.getId(), e.getName(), e.getDate(), e.getLocation(),
                e.getCapacity(), registered, e.getCapacity() - registered, e.getCategory());
    }
}
