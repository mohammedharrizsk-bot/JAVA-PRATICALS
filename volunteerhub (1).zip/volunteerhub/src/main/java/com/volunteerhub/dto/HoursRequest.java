package com.volunteerhub.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public record HoursRequest(
        @NotNull(message = "hoursContributed is required")
        @PositiveOrZero(message = "Hours must be zero or more")
        Double hoursContributed) {
}
