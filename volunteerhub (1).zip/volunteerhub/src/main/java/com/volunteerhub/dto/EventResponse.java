package com.volunteerhub.dto;

import com.volunteerhub.entity.Event;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record EventResponse(
        Long id,
        String name,
        String description,
        LocalDate date,
        String location,
        Integer capacity,
        String category,
        LocalDateTime createdAt) {

    public static EventResponse from(Event e) {
        return new EventResponse(e.getId(), e.getName(), e.getDescription(), e.getDate(),
                e.getLocation(), e.getCapacity(), e.getCategory(), e.getCreatedAt());
    }
}
