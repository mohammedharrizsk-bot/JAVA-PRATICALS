package com.volunteerhub.dto;

import jakarta.validation.constraints.NotNull;

public record SignupRequest(
        @NotNull(message = "volunteerId is required")
        Long volunteerId) {
}
