package com.volunteerhub.dto;

public record DashboardResponse(
        long totalEvents,
        long upcomingEvents,
        long totalVolunteers,
        long totalSignups,
        double totalVolunteerHours) {
}
