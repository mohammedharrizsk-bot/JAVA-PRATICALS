package com.volunteerhub.dto;

import com.volunteerhub.entity.Volunteer;

import java.time.LocalDate;

public record VolunteerResponse(
        Long id,
        String name,
        String email,
        String phone,
        LocalDate registrationDate,
        boolean active) {

    public static VolunteerResponse from(Volunteer v) {
        return new VolunteerResponse(v.getId(), v.getName(), v.getEmail(), v.getPhone(),
                v.getRegistrationDate(), v.isActive());
    }
}
