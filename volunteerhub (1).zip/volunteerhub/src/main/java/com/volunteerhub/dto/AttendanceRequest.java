package com.volunteerhub.dto;

import jakarta.validation.constraints.NotNull;

public record AttendanceRequest(
        @NotNull(message = "signupId is required")
        Long signupId,

        @NotNull(message = "attended is required (true or false)")
        Boolean attended) {
}
