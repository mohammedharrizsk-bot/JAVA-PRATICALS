package com.volunteerhub.config;

import com.volunteerhub.entity.*;
import com.volunteerhub.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * Inserts sample data on startup (only if the database is empty).
 * Not used in the "test" profile.
 */
@Component
@Profile("!test")
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final VolunteerRepository volunteerRepository;
    private final EventRepository eventRepository;
    private final SignUpRepository signUpRepository;
    private final AttendanceRecordRepository attendanceRepository;

    @Override
    public void run(String... args) {
        if (volunteerRepository.count() > 0) {
            return;
        }

        // 5 volunteers
        Volunteer john = volunteer("John Doe", "john@example.com", "9876543210");
        Volunteer priya = volunteer("Priya Sharma", "priya@example.com", "9876543211");
        Volunteer arun = volunteer("Arun Kumar", "arun@example.com", "9876543212");
        Volunteer meena = volunteer("Meena Iyer", "meena@example.com", "9876543213");
        volunteer("Rahul Verma", "rahul@example.com", "9876543214"); // has no sign-ups yet

        // 3 events
        Event beach = event("Beach Cleanup Drive", "Community beach cleaning activity",
                LocalDate.now().plusDays(14), "Marina Beach", 50, "Environment");   // OPEN SLOTS
        Event blood = event("Blood Donation Camp", "Campus blood donation camp",
                LocalDate.now().plusDays(7), "College Auditorium", 3, "Health");      // FULL
        Event trees = event("Tree Plantation Drive", "Planting saplings near the lake",
                LocalDate.now().minusDays(7), "Lake Park", 10, "Environment");        // already happened

        // Sign-ups
        signUp(john, beach);
        signUp(priya, beach);
        signUp(arun, beach);

        signUp(john, blood);
        signUp(priya, blood);
        signUp(meena, blood);                 // 3 of 3 -> FULL

        SignUp s1 = signUp(john, trees);
        SignUp s2 = signUp(priya, trees);
        SignUp s3 = signUp(arun, trees);
        SignUp s4 = signUp(meena, trees);

        // Attendance + hours for the past event
        attendance(s1, true, 4.5);
        attendance(s2, true, 3.0);
        attendance(s3, true, 5.0);
        attendance(s4, false, 0.0);
    }

    private Volunteer volunteer(String name, String email, String phone) {
        Volunteer v = new Volunteer();
        v.setName(name);
        v.setEmail(email);
        v.setPhone(phone);
        return volunteerRepository.save(v);
    }

    private Event event(String name, String description, LocalDate date, String location,
                        int capacity, String category) {
        Event e = new Event();
        e.setName(name);
        e.setDescription(description);
        e.setDate(date);
        e.setLocation(location);
        e.setCapacity(capacity);
        e.setCategory(category);
        return eventRepository.save(e);
    }

    private SignUp signUp(Volunteer volunteer, Event event) {
        SignUp s = new SignUp();
        s.setVolunteer(volunteer);
        s.setEvent(event);
        s.setStatus(SignUpStatus.REGISTERED);
        return signUpRepository.save(s);
    }

    private void attendance(SignUp signUp, boolean attended, double hours) {
        AttendanceRecord a = new AttendanceRecord();
        a.setSignup(signUp);
        a.setAttended(attended);
        a.setHoursContributed(hours);
        attendanceRepository.save(a);
    }
}
