package com.volunteerhub.entity;

public enum SignUpStatus {
    REGISTERED,
    CANCELLED
}
