package com.volunteerhub.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/** Links one Volunteer to one Event. */
@Entity
@Table(name = "signups")
@Getter
@Setter
@NoArgsConstructor
public class SignUp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "volunteer_id")
    private Volunteer volunteer;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "event_id")
    private Event event;

    private LocalDateTime signupTime;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SignUpStatus status = SignUpStatus.REGISTERED;

    @PrePersist
    void onCreate() {
        this.signupTime = LocalDateTime.now();
    }
}
