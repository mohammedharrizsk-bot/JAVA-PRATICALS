package com.volunteerhub.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * One attendance record per sign-up.
 * The volunteer and the event are reached through the sign-up
 * (signup.getVolunteer() / signup.getEvent()), so we do not duplicate them here.
 */
@Entity
@Table(name = "attendance_records")
@Getter
@Setter
@NoArgsConstructor
public class AttendanceRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "signup_id", unique = true)
    private SignUp signup;

    @Column(nullable = false)
    private boolean attended;

    @Column(nullable = false)
    private Double hoursContributed = 0.0;

    private LocalDateTime attendanceTime;

    @PrePersist
    void onCreate() {
        this.attendanceTime = LocalDateTime.now();
    }
}
