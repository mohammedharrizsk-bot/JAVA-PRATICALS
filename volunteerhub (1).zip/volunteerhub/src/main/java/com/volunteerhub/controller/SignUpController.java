package com.volunteerhub.controller;

import com.volunteerhub.dto.SignUpResponse;
import com.volunteerhub.dto.SignupRequest;
import com.volunteerhub.service.SignUpService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class SignUpController {

    private final SignUpService signUpService;

    @PostMapping("/events/{eventId}/signup")
    @ResponseStatus(HttpStatus.CREATED)
    public SignUpResponse signUp(@PathVariable Long eventId, @Valid @RequestBody SignupRequest request) {
        return signUpService.signUp(eventId, request.volunteerId());
    }

    @GetMapping("/events/{eventId}/signups")
    public List<SignUpResponse> getSignUpsForEvent(@PathVariable Long eventId) {
        return signUpService.getSignUpsForEvent(eventId);
    }

    @GetMapping("/volunteers/{volunteerId}/signups")
    public List<SignUpResponse> getSignUpsForVolunteer(@PathVariable Long volunteerId) {
        return signUpService.getSignUpsForVolunteer(volunteerId);
    }

    @DeleteMapping("/signups/{signupId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void cancelSignUp(@PathVariable Long signupId) {
        signUpService.cancelSignUp(signupId);
    }
}
