package com.volunteerhub.controller;

import com.volunteerhub.dto.AttendanceRequest;
import com.volunteerhub.dto.AttendanceResponse;
import com.volunteerhub.dto.AttendanceUpdateRequest;
import com.volunteerhub.dto.HoursRequest;
import com.volunteerhub.service.AttendanceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AttendanceController {

    private final AttendanceService attendanceService;

    @PostMapping("/attendance")
    @ResponseStatus(HttpStatus.CREATED)
    public AttendanceResponse markAttendance(@Valid @RequestBody AttendanceRequest request) {
        return attendanceService.markAttendance(request);
    }

    @PutMapping("/attendance/{id}")
    public AttendanceResponse updateAttendance(@PathVariable Long id,
                                               @Valid @RequestBody AttendanceUpdateRequest request) {
        return attendanceService.updateAttendance(id, request.attended());
    }

    @PutMapping("/attendance/{id}/hours")
    public AttendanceResponse recordHours(@PathVariable Long id, @Valid @RequestBody HoursRequest request) {
        return attendanceService.recordHours(id, request.hoursContributed());
    }

    @GetMapping("/events/{eventId}/attendance")
    public List<AttendanceResponse> getAttendanceForEvent(@PathVariable Long eventId) {
        return attendanceService.getAttendanceForEvent(eventId);
    }
}
