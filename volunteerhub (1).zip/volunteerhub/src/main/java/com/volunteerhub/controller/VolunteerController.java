package com.volunteerhub.controller;

import com.volunteerhub.dto.VolunteerHoursResponse;
import com.volunteerhub.dto.VolunteerRequest;
import com.volunteerhub.dto.VolunteerResponse;
import com.volunteerhub.service.VolunteerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/volunteers")
@RequiredArgsConstructor
public class VolunteerController {

    private final VolunteerService volunteerService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public VolunteerResponse createVolunteer(@Valid @RequestBody VolunteerRequest request) {
        return volunteerService.createVolunteer(request);
    }

    @GetMapping
    public List<VolunteerResponse> getAllVolunteers() {
        return volunteerService.getAllVolunteers();
    }

    @GetMapping("/{id}")
    public VolunteerResponse getVolunteer(@PathVariable Long id) {
        return volunteerService.getVolunteer(id);
    }

    @GetMapping("/{id}/hours")
    public VolunteerHoursResponse getTotalHours(@PathVariable Long id) {
        return volunteerService.getTotalHours(id);
    }
}
