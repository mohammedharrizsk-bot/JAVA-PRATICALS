package com.volunteerhub.repository;

import com.volunteerhub.entity.Volunteer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VolunteerRepository extends JpaRepository<Volunteer, Long> {

    boolean existsByEmail(String email);
}
