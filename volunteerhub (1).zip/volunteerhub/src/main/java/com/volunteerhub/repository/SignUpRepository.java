package com.volunteerhub.repository;

import com.volunteerhub.entity.SignUp;
import com.volunteerhub.entity.SignUpStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SignUpRepository extends JpaRepository<SignUp, Long> {

    long countByEventIdAndStatus(Long eventId, SignUpStatus status);

    long countByStatus(SignUpStatus status);

    boolean existsByVolunteerIdAndEventIdAndStatus(Long volunteerId, Long eventId, SignUpStatus status);

    boolean existsByEventId(Long eventId);

    List<SignUp> findByEventId(Long eventId);

    List<SignUp> findByVolunteerId(Long volunteerId);
}
