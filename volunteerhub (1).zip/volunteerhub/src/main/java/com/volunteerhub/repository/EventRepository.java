package com.volunteerhub.repository;

import com.volunteerhub.entity.Event;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface EventRepository extends JpaRepository<Event, Long> {

    /** Upcoming events (today or later), earliest first. */
    List<Event> findByDateGreaterThanEqualOrderByDateAsc(LocalDate date);

    long countByDateGreaterThanEqual(LocalDate date);

    /**
     * Loads the event and LOCKS its row until the transaction ends.
     * Two people signing up for the last slot at the same time are handled one after the other.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select e from Event e where e.id = :id")
    Optional<Event> findByIdForUpdate(@Param("id") Long id);
}
