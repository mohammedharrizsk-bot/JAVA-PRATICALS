package com.volunteerhub.repository;

import com.volunteerhub.entity.AttendanceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AttendanceRecordRepository extends JpaRepository<AttendanceRecord, Long> {

    boolean existsBySignupId(Long signupId);

    /** All attendance records of one event (goes signup -> event). */
    List<AttendanceRecord> findBySignupEventId(Long eventId);

    /** Total hours of one volunteer. Only records with attended = true are counted. */
    @Query("select coalesce(sum(a.hoursContributed), 0) from AttendanceRecord a "
            + "where a.signup.volunteer.id = :volunteerId and a.attended = true")
    Double totalHoursByVolunteer(@Param("volunteerId") Long volunteerId);

    /** Total hours of everyone (attended only). */
    @Query("select coalesce(sum(a.hoursContributed), 0) from AttendanceRecord a where a.attended = true")
    Double totalHoursOfAll();
}
