package com.volunteerhub.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

/** Base class for all "expected" errors. It carries the HTTP status and an error code. */
@Getter
public class BusinessException extends RuntimeException {

    private final HttpStatus status;
    private final String errorCode;

    public BusinessException(HttpStatus status, String errorCode, String message) {
        super(message);
        this.status = status;
        this.errorCode = errorCode;
    }
}
