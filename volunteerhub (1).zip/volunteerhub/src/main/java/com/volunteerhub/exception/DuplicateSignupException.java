package com.volunteerhub.exception;

import org.springframework.http.HttpStatus;

public class DuplicateSignupException extends BusinessException {

    public DuplicateSignupException() {
        super(HttpStatus.CONFLICT, "DUPLICATE_SIGNUP", "This volunteer is already registered for this event.");
    }
}
