package com.volunteerhub.exception;

import org.springframework.http.HttpStatus;

public class InvalidHoursException extends BusinessException {

    public InvalidHoursException() {
        super(HttpStatus.BAD_REQUEST, "INVALID_HOURS", "Hours contributed must be zero or more.");
    }
}
