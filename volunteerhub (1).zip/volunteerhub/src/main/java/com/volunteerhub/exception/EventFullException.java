package com.volunteerhub.exception;

import org.springframework.http.HttpStatus;

public class EventFullException extends BusinessException {

    public EventFullException() {
        super(HttpStatus.CONFLICT, "EVENT_FULL", "This event has reached its volunteer capacity.");
    }
}
