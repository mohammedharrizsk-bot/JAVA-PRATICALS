package com.volunteerhub.exception;

import org.springframework.http.HttpStatus;

public class VolunteerNotAttendedException extends BusinessException {

    public VolunteerNotAttendedException() {
        super(HttpStatus.BAD_REQUEST, "VOLUNTEER_NOT_ATTENDED",
                "Hours can only be recorded for volunteers marked as attended.");
    }
}
