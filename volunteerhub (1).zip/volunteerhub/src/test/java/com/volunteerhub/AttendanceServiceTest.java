package com.volunteerhub;

import com.volunteerhub.dto.AttendanceRequest;
import com.volunteerhub.dto.AttendanceResponse;
import com.volunteerhub.entity.*;
import com.volunteerhub.exception.InvalidHoursException;
import com.volunteerhub.exception.VolunteerNotAttendedException;
import com.volunteerhub.repository.AttendanceRecordRepository;
import com.volunteerhub.repository.EventRepository;
import com.volunteerhub.repository.SignUpRepository;
import com.volunteerhub.service.AttendanceService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Unit tests for the attendance and hours business rules. */
@ExtendWith(MockitoExtension.class)
class AttendanceServiceTest {

    @Mock
    private AttendanceRecordRepository attendanceRepository;
    @Mock
    private SignUpRepository signUpRepository;
    @Mock
    private EventRepository eventRepository;

    @InjectMocks
    private AttendanceService attendanceService;

    private SignUp signUp() {
        Volunteer v = new Volunteer();
        v.setId(1L);
        v.setName("John Doe");

        Event e = new Event();
        e.setId(1L);
        e.setName("Beach Cleanup Drive");

        SignUp s = new SignUp();
        s.setId(15L);
        s.setVolunteer(v);
        s.setEvent(e);
        s.setStatus(SignUpStatus.REGISTERED);
        return s;
    }

    private AttendanceRecord record(boolean attended) {
        AttendanceRecord r = new AttendanceRecord();
        r.setId(1L);
        r.setSignup(signUp());
        r.setAttended(attended);
        return r;
    }

    @Test
    void markVolunteerAsAttended() {
        when(signUpRepository.findById(15L)).thenReturn(Optional.of(signUp()));
        when(attendanceRepository.save(any(AttendanceRecord.class))).thenAnswer(inv -> inv.getArgument(0));

        AttendanceResponse response = attendanceService.markAttendance(new AttendanceRequest(15L, true));

        assertTrue(response.attended());
        assertEquals("ATTENDED", response.attendanceStatus());
    }

    @Test
    void markVolunteerAsNotAttended() {
        when(signUpRepository.findById(15L)).thenReturn(Optional.of(signUp()));
        when(attendanceRepository.save(any(AttendanceRecord.class))).thenAnswer(inv -> inv.getArgument(0));

        AttendanceResponse response = attendanceService.markAttendance(new AttendanceRequest(15L, false));

        assertFalse(response.attended());
        assertEquals("NOT_ATTENDED", response.attendanceStatus());
    }

    @Test
    void hoursSavedForAttendedVolunteer() {
        when(attendanceRepository.findById(1L)).thenReturn(Optional.of(record(true)));
        when(attendanceRepository.save(any(AttendanceRecord.class))).thenAnswer(inv -> inv.getArgument(0));

        AttendanceResponse response = attendanceService.recordHours(1L, 4.5);

        assertEquals(4.5, response.hoursContributed());
    }

    @Test
    void hoursRejectedForVolunteerWhoDidNotAttend() {
        when(attendanceRepository.findById(1L)).thenReturn(Optional.of(record(false)));

        assertThrows(VolunteerNotAttendedException.class, () -> attendanceService.recordHours(1L, 4.5));
        verify(attendanceRepository, never()).save(any());
    }

    @Test
    void negativeHoursRejected() {
        when(attendanceRepository.findById(1L)).thenReturn(Optional.of(record(true)));

        assertThrows(InvalidHoursException.class, () -> attendanceService.recordHours(1L, -2.0));
        verify(attendanceRepository, never()).save(any());
    }
}
