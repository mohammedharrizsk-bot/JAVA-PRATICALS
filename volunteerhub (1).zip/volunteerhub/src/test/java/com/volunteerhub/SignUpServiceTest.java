package com.volunteerhub;

import com.volunteerhub.dto.SignUpResponse;
import com.volunteerhub.entity.Event;
import com.volunteerhub.entity.SignUp;
import com.volunteerhub.entity.SignUpStatus;
import com.volunteerhub.entity.Volunteer;
import com.volunteerhub.exception.DuplicateSignupException;
import com.volunteerhub.exception.EventFullException;
import com.volunteerhub.exception.ResourceNotFoundException;
import com.volunteerhub.repository.EventRepository;
import com.volunteerhub.repository.SignUpRepository;
import com.volunteerhub.repository.VolunteerRepository;
import com.volunteerhub.service.SignUpService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Unit tests for the sign-up business rules (no database, repositories are mocked). */
@ExtendWith(MockitoExtension.class)
class SignUpServiceTest {

    @Mock
    private SignUpRepository signUpRepository;
    @Mock
    private EventRepository eventRepository;
    @Mock
    private VolunteerRepository volunteerRepository;

    @InjectMocks
    private SignUpService signUpService;

    private Volunteer volunteer() {
        Volunteer v = new Volunteer();
        v.setId(1L);
        v.setName("John Doe");
        v.setEmail("john@example.com");
        v.setPhone("9876543210");
        return v;
    }

    private Event event(int capacity) {
        Event e = new Event();
        e.setId(1L);
        e.setName("Beach Cleanup Drive");
        e.setDate(LocalDate.now().plusDays(5));
        e.setLocation("Marina Beach");
        e.setCapacity(capacity);
        return e;
    }

    @Test
    void volunteerSignsUpSuccessfully() {
        when(volunteerRepository.findById(1L)).thenReturn(Optional.of(volunteer()));
        when(eventRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(event(3)));
        when(signUpRepository.existsByVolunteerIdAndEventIdAndStatus(1L, 1L, SignUpStatus.REGISTERED))
                .thenReturn(false);
        when(signUpRepository.countByEventIdAndStatus(1L, SignUpStatus.REGISTERED)).thenReturn(2L);
        when(signUpRepository.save(any(SignUp.class))).thenAnswer(inv -> inv.getArgument(0));

        SignUpResponse response = signUpService.signUp(1L, 1L);

        assertEquals(SignUpStatus.REGISTERED, response.status());
        assertEquals("John Doe", response.volunteerName());
        verify(signUpRepository).save(any(SignUp.class));
    }

    @Test
    void signUpRejectedWhenEventIsFull() {
        when(volunteerRepository.findById(1L)).thenReturn(Optional.of(volunteer()));
        when(eventRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(event(3)));
        when(signUpRepository.countByEventIdAndStatus(1L, SignUpStatus.REGISTERED)).thenReturn(3L);

        assertThrows(EventFullException.class, () -> signUpService.signUp(1L, 1L));
        verify(signUpRepository, never()).save(any());
    }

    @Test
    void duplicateSignUpRejected() {
        when(volunteerRepository.findById(1L)).thenReturn(Optional.of(volunteer()));
        when(eventRepository.findByIdForUpdate(1L)).thenReturn(Optional.of(event(3)));
        when(signUpRepository.existsByVolunteerIdAndEventIdAndStatus(1L, 1L, SignUpStatus.REGISTERED))
                .thenReturn(true);

        assertThrows(DuplicateSignupException.class, () -> signUpService.signUp(1L, 1L));
        verify(signUpRepository, never()).save(any());
    }

    @Test
    void signUpRejectedWhenVolunteerDoesNotExist() {
        when(volunteerRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> signUpService.signUp(1L, 99L));
        verify(signUpRepository, never()).save(any());
    }

    @Test
    void signUpRejectedWhenEventDoesNotExist() {
        when(volunteerRepository.findById(1L)).thenReturn(Optional.of(volunteer()));
        when(eventRepository.findByIdForUpdate(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> signUpService.signUp(99L, 1L));
        verify(signUpRepository, never()).save(any());
    }
}
