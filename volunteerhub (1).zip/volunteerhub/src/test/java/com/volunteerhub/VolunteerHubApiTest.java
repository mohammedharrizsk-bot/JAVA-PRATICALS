package com.volunteerhub;

import com.volunteerhub.entity.*;
import com.volunteerhub.repository.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Integration tests: real Spring context + in-memory H2 database + real HTTP layer (MockMvc).
 * Every test is rolled back automatically (@Transactional), so tests do not affect each other.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class VolunteerHubApiTest {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private EventRepository eventRepository;
    @Autowired
    private VolunteerRepository volunteerRepository;
    @Autowired
    private SignUpRepository signUpRepository;
    @Autowired
    private AttendanceRecordRepository attendanceRepository;

    // ---------- helpers to prepare data ----------
    private Event saveEvent(String name, LocalDate date, int capacity) {
        Event e = new Event();
        e.setName(name);
        e.setDate(date);
        e.setLocation("Marina Beach");
        e.setCapacity(capacity);
        e.setCategory("Environment");
        return eventRepository.save(e);
    }

    private Volunteer saveVolunteer(String name, String email) {
        Volunteer v = new Volunteer();
        v.setName(name);
        v.setEmail(email);
        v.setPhone("9876543210");
        return volunteerRepository.save(v);
    }

    private SignUp saveSignUp(Volunteer v, Event e) {
        SignUp s = new SignUp();
        s.setVolunteer(v);
        s.setEvent(e);
        s.setStatus(SignUpStatus.REGISTERED);
        return signUpRepository.save(s);
    }

    private AttendanceRecord saveAttendance(SignUp s, boolean attended, double hours) {
        AttendanceRecord a = new AttendanceRecord();
        a.setSignup(s);
        a.setAttended(attended);
        a.setHoursContributed(hours);
        return attendanceRepository.save(a);
    }

    // ---------- Event ----------
    @Test
    void createEventSuccessfully() throws Exception {
        String body = """
                {"name":"Beach Cleanup Drive","description":"Community beach cleaning activity",
                 "date":"2026-10-15","location":"Marina Beach","capacity":50,"category":"Environment"}
                """;

        mockMvc.perform(post("/api/events").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", notNullValue()))
                .andExpect(jsonPath("$.name").value("Beach Cleanup Drive"))
                .andExpect(jsonPath("$.capacity").value(50));
    }

    @Test
    void invalidCapacityRejected() throws Exception {
        String body = """
                {"name":"Beach Cleanup","date":"2026-10-15","location":"Marina Beach","capacity":0}
                """;

        mockMvc.perform(post("/api/events").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("VALIDATION_ERROR"))
                .andExpect(jsonPath("$.fieldErrors.capacity").exists());
    }

    @Test
    void missingRequiredFieldsRejected() throws Exception {
        mockMvc.perform(post("/api/events").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.name").exists())
                .andExpect(jsonPath("$.fieldErrors.date").exists())
                .andExpect(jsonPath("$.fieldErrors.location").exists())
                .andExpect(jsonPath("$.fieldErrors.capacity").exists());
    }

    // ---------- Volunteer ----------
    @Test
    void createVolunteerSuccessfully() throws Exception {
        String body = """
                {"name":"John Doe","email":"john@example.com","phone":"9876543210"}
                """;

        mockMvc.perform(post("/api/volunteers").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.email").value("john@example.com"))
                .andExpect(jsonPath("$.active").value(true));
    }

    @Test
    void invalidEmailRejected() throws Exception {
        String body = """
                {"name":"John Doe","email":"not-an-email","phone":"9876543210"}
                """;

        mockMvc.perform(post("/api/volunteers").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.email").exists());
    }

    // ---------- Sign-up (through the real API) ----------
    @Test
    void signUpRejectedWhenEventFull() throws Exception {
        Event event = saveEvent("Tiny Event", LocalDate.now().plusDays(3), 1);
        saveSignUp(saveVolunteer("First", "first@example.com"), event);
        Volunteer second = saveVolunteer("Second", "second@example.com");

        mockMvc.perform(post("/api/events/" + event.getId() + "/signup")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"volunteerId\":" + second.getId() + "}"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.error").value("EVENT_FULL"));
    }

    @Test
    void duplicateSignUpRejected() throws Exception {
        Event event = saveEvent("Big Event", LocalDate.now().plusDays(3), 10);
        Volunteer volunteer = saveVolunteer("John", "john@example.com");
        String body = "{\"volunteerId\":" + volunteer.getId() + "}";

        mockMvc.perform(post("/api/events/" + event.getId() + "/signup")
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isCreated());

        mockMvc.perform(post("/api/events/" + event.getId() + "/signup")
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.error").value("DUPLICATE_SIGNUP"));
    }

    @Test
    void signUpWithUnknownVolunteerReturns404() throws Exception {
        Event event = saveEvent("Event", LocalDate.now().plusDays(3), 10);

        mockMvc.perform(post("/api/events/" + event.getId() + "/signup")
                        .contentType(MediaType.APPLICATION_JSON).content("{\"volunteerId\":9999}"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").value("RESOURCE_NOT_FOUND"));
    }

    // ---------- Hours ----------
    @Test
    void hoursRejectedThroughApiWhenNotAttended() throws Exception {
        Event event = saveEvent("Past Event", LocalDate.now().minusDays(2), 10);
        SignUp signUp = saveSignUp(saveVolunteer("John", "john@example.com"), event);
        AttendanceRecord record = saveAttendance(signUp, false, 0.0);

        mockMvc.perform(put("/api/attendance/" + record.getId() + "/hours")
                        .contentType(MediaType.APPLICATION_JSON).content("{\"hoursContributed\":4.5}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("VOLUNTEER_NOT_ATTENDED"));
    }

    @Test
    void hoursSavedThroughApiWhenAttended() throws Exception {
        Event event = saveEvent("Past Event", LocalDate.now().minusDays(2), 10);
        SignUp signUp = saveSignUp(saveVolunteer("John", "john@example.com"), event);
        AttendanceRecord record = saveAttendance(signUp, true, 0.0);

        mockMvc.perform(put("/api/attendance/" + record.getId() + "/hours")
                        .contentType(MediaType.APPLICATION_JSON).content("{\"hoursContributed\":4.5}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.hoursContributed").value(4.5));
    }

    @Test
    void negativeHoursRejectedThroughApi() throws Exception {
        Event event = saveEvent("Past Event", LocalDate.now().minusDays(2), 10);
        SignUp signUp = saveSignUp(saveVolunteer("John", "john@example.com"), event);
        AttendanceRecord record = saveAttendance(signUp, true, 0.0);

        mockMvc.perform(put("/api/attendance/" + record.getId() + "/hours")
                        .contentType(MediaType.APPLICATION_JSON).content("{\"hoursContributed\":-1}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("VALIDATION_ERROR"));
    }

    // ---------- Total hours ----------
    @Test
    void totalHoursCountsOnlyAttendedRecords() throws Exception {
        Volunteer john = saveVolunteer("John Doe", "john@example.com");
        Event e1 = saveEvent("Past 1", LocalDate.now().minusDays(10), 10);
        Event e2 = saveEvent("Past 2", LocalDate.now().minusDays(5), 10);
        Event e3 = saveEvent("Past 3", LocalDate.now().minusDays(2), 10);

        saveAttendance(saveSignUp(john, e1), true, 4.0);
        saveAttendance(saveSignUp(john, e2), true, 2.5);
        saveAttendance(saveSignUp(john, e3), false, 9.0);   // must NOT be counted

        mockMvc.perform(get("/api/volunteers/" + john.getId() + "/hours"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.volunteerName").value("John Doe"))
                .andExpect(jsonPath("$.totalHours").value(6.5));
    }

    // ---------- Upcoming events ----------
    @Test
    void upcomingReturnsOpenEventsAndExcludesFullAndPast() throws Exception {
        saveEvent("Open Future Event", LocalDate.now().plusDays(5), 5);
        Event full = saveEvent("Full Future Event", LocalDate.now().plusDays(3), 1);
        saveSignUp(saveVolunteer("John", "john@example.com"), full);
        saveEvent("Past Event", LocalDate.now().minusDays(1), 5);

        mockMvc.perform(get("/api/events/upcoming"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].name").value("Open Future Event"))
                .andExpect(jsonPath("$[0].registeredVolunteers").value(0))
                .andExpect(jsonPath("$[0].openSlots").value(5));
    }

    // ---------- Filter + Dashboard ----------
    @Test
    void eventsCanBeFilteredByCategory() throws Exception {
        saveEvent("Env Event", LocalDate.now().plusDays(5), 5);   // category Environment

        mockMvc.perform(get("/api/events").param("category", "environment"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)));
        mockMvc.perform(get("/api/events").param("category", "Health"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)));
    }

    @Test
    void dashboardReturnsTotals() throws Exception {
        Volunteer john = saveVolunteer("John", "john@example.com");
        Event past = saveEvent("Past", LocalDate.now().minusDays(3), 5);
        saveEvent("Future", LocalDate.now().plusDays(3), 5);
        saveAttendance(saveSignUp(john, past), true, 3.0);

        mockMvc.perform(get("/api/dashboard"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalEvents").value(2))
                .andExpect(jsonPath("$.upcomingEvents").value(1))
                .andExpect(jsonPath("$.totalVolunteers").value(1))
                .andExpect(jsonPath("$.totalSignups").value(1))
                .andExpect(jsonPath("$.totalVolunteerHours").value(3.0));
    }
}
